# JADE Debate Tab

A premium static website app for managing debate tournaments with support for:

- Opening and closing tournaments
- Public or hidden standings
- System administrators, tab managers, judges, and debaters
- Judge feedback submission
- Email-based tab manager permissions
- Private debater URLs for draw and standings access
- Team standings that can follow BP team points or AP/World Schools win-loss point models
- Separate speaker-score rankings for both team and individual tournaments
- Round-by-round structure planning so different rounds can use different team counts and team sizes
- British Parliamentary, American Parliamentary, JADE Parliamentary, Iron Person British Parliamentary, and World Schools formats
- No Standard Format tournaments with custom rules and structure
- Team-based, individual, and hybrid participation models
- Optional cross-examination scoring with questions out of 20 and responses out of 40
- Optional rebuttal scoring out of 50
- Password-based sign-in for every account
- A forgot-password request flow that sends recovery requests to the manager dashboard
- Self sign-up so users can create their own passwords
- A manager-controlled settings area for branding, security, portal behaviour, feedback defaults, and tournament defaults
- A redesigned sign-in experience with built-in forgot-password requests
- A compact private debater portal designed to feel clear, premium, and calm for competitors
- A dedicated competitor-only signed-in dashboard that hides manager controls and keeps navigation compact
- A focused per-tournament tab room with team creation, speaker registration, draw generation, round release, and standings review
- Draw methods for random pairing, power pairing, and folded rounds
- A live round control board with release status, ballot progress, judge check-ins, room readiness, and debate priority
- Debate-priority-aware judge allocation so stronger rooms can receive stronger panels first
- Optional public team aliases or code names for published boards and public-facing views
- Tournament appointee dashboards with role changes and removals directly inside the People area
- Manager tools for account creation, password resets, tournament duplication, invitation handling, and deletion of tournaments or users
- A built-in About page shaped around JADE’s public mission and tournament-development focus

## Run it locally

The app runs from these local files:

- [index.html](/Users/jo/Documents/New%20project/index.html)
- [jade-logo.jpg](/Users/jo/Documents/New%20project/jade-logo.jpg)

Open [index.html](/Users/jo/Documents/New%20project/index.html) directly in your browser. The app keeps its CSS and JavaScript in that file and uses the included JADE logo image for branding.

## Publish it as a website

This project is now packaged for static hosting.

Included website files:

- [index.html](/Users/jo/Documents/New%20project/index.html)
- [site.webmanifest](/Users/jo/Documents/New%20project/site.webmanifest)
- [robots.txt](/Users/jo/Documents/New%20project/robots.txt)
- [netlify.toml](/Users/jo/Documents/New%20project/netlify.toml)
- [_redirects](/Users/jo/Documents/New%20project/_redirects)
- [_headers](/Users/jo/Documents/New%20project/_headers)
- [vercel.json](/Users/jo/Documents/New%20project/vercel.json)

## Netlify publish path

This is the cleanest hosting option for the current project.

Fastest way:

1. Open Netlify and choose `Add new site` -> `Deploy manually`
2. Drag the entire folder `/Users/jo/Documents/New project`
3. Netlify will publish the static site directly

Connected-project way:

1. Put this folder in a Git repository
2. Import the repository into Netlify
3. Keep the publish directory as the project root `.`
4. No build command is required

Netlify files already included:

- `netlify.toml` for publish settings
- `_redirects` so all app routes and access-link URLs resolve back through `index.html`
- `_headers` for basic response headers

Private access links and account access links use the live site URL automatically once the website is opened from its real hosted domain.

## Demo accounts

- Manager: `joshuaatkins374@gmail.com`
- Manager password: `manager@debate.com`
- Sample tab manager: `tab@debate.org` / `tab@debate.com`
- Sample judge: `judge@debate.org` / `judge@debate.com`
- Sample debater: `debater@debate.org` / `debater@debate.com`

## Notes

- Data is stored in `localStorage`, so changes persist in the browser you use.
- Because this is a static website, each browser/device keeps its own local tournament data unless you later connect a backend database.
- Each signed-in account now has its own private access URL, and managers can also copy or rotate access URLs for other users.
- Hidden standings stay off the public dashboard but remain visible inside the debater's private link.
- The global manager account is fixed to `joshuaatkins374@gmail.com`.
- New users can sign up with their own email and create a password.
- The manager can create staff accounts, review forgot-password requests, reset passwords, duplicate tournaments as templates, remove users, and copy invitation messages from the app.
- Team tournaments can keep team standings and speaker rankings separate, so speakers still receive speaker scores while teams are ranked on the correct team-point model.
- Tournament structures can vary by round, so admins are not locked into one room or team format for the whole event.
- Draw rooms can now track priority, room check-ins, judge check-ins, and ballot return status without leaving the tournament workspace.
- The private portal now prioritizes each competitor's own round, standing snapshot, and feedback before exposing any full published boards.
- This is an MVP scaffold intended to validate workflows before connecting a real backend, database, authentication provider, and email system.
